# Tests & Reports

Die Tests prüfen alle Endpoints (Systemtest, Idee, Analyse, Execution) inklusive Fehlerpfad.
Jeder Test erzeugt eine **Text-Reportdatei** im Ordner `Report/` mit Summary und JSON-Details.

## Ausführen
```bash
# im Projektroot
python3 -m venv .venv && source .venv/bin/activate
pip install fastapi uvicorn pydantic pytest

# Backend starten (Terminal A)
uvicorn app:app --reload --app-dir Backend

# Tests starten (Terminal B)
pytest -q
```