import sys
from pathlib import Path
from fastapi.testclient import TestClient

def load_app():
    try:
        from Backend.app import app  # type: ignore
        return app
    except Exception:
        import importlib.util
        backend_dir = Path(__file__).resolve().parents[1] / "Backend"
        app_file = backend_dir / "app.py"
        spec = importlib.util.spec_from_file_location("backend_app", app_file)
        module = importlib.util.module_from_spec(spec)  # type: ignore
        assert spec and spec.loader, "Cannot load spec for Backend/app.py"
        spec.loader.exec_module(module)  # type: ignore
        return module.app

from .utils_report import write_report

def proj_root() -> Path:
    return Path(__file__).resolve().parents[1]

class TempRename:
    def __init__(self, p: Path):
        self.p = p
        self.bak = p.with_suffix(p.suffix + ".bak")
    def __enter__(self):
        if self.p.exists():
            self.p.rename(self.bak)
    def __exit__(self, exc_type, exc, tb):
        if self.bak.exists():
            self.bak.rename(self.p)

app = load_app()
client = TestClient(app)

def test_systemtest_ok():
    r = client.get("/api/systemtest")
    ok = (r.status_code == 200 and r.json().get("ok") is True)
    status = "PASS" if ok else "FAIL"
    write_report("systemtest_ok", {
        "status": status,
        "endpoint": "/api/systemtest",
        "expected": "{ ok: true, report: '10/10 Pass ...' }",
        "actual": r.json()
    })
    assert ok

def test_idea_ok_and_error():
    backend_dir = proj_root() / "Backend"
    idea_file = backend_dir / "idee.txt"

    r_ok = client.get("/api/idea")
    ok = (r_ok.status_code == 200 and r_ok.json().get("ok") is True and "idea" in r_ok.json())
    write_report("idea_ok", {
        "status": "PASS" if ok else "FAIL",
        "endpoint": "/api/idea",
        "expected": "{ ok: true, idea: '<text>' }",
        "actual": r_ok.json()
    })
    assert ok

    with TempRename(idea_file):
        r_err = client.get("/api/idea")
        ok_err = (r_err.status_code == 200 and r_err.json().get("ok") is False and "error" in r_err.json())
        write_report("idea_error", {
            "status": "PASS" if ok_err else "FAIL",
            "endpoint": "/api/idea",
            "expected": "{ ok: false, error: '<msg>' } when file missing",
            "actual": r_err.json(),
            "note": "idee.txt temporarily renamed to simulate error"
        })
        assert ok_err

def test_analysis_ok_and_error():
    backend_dir = proj_root() / "Backend"
    ana_file = backend_dir / "analyse.txt"

    r_ok = client.get("/api/analysis")
    ok = (r_ok.status_code == 200 and r_ok.json().get("ok") is True and "analysis" in r_ok.json())
    write_report("analysis_ok", {
        "status": "PASS" if ok else "FAIL",
        "endpoint": "/api/analysis",
        "expected": "{ ok: true, analysis: '<text>' }",
        "actual": r_ok.json()
    })
    assert ok

    with TempRename(ana_file):
        r_err = client.get("/api/analysis")
        ok_err = (r_err.status_code == 200 and r_err.json().get("ok") is False and "error" in r_err.json())
        write_report("analysis_error", {
            "status": "PASS" if ok_err else "FAIL",
            "endpoint": "/api/analysis",
            "expected": "{ ok: false, error: '<msg>' } when file missing",
            "actual": r_err.json(),
            "note": "analyse.txt temporarily renamed to simulate error"
        })
        assert ok_err

def test_execute_ok_and_error():
    backend_dir = proj_root() / "Backend"
    exe_file = backend_dir / "execution.txt"

    r_ok = client.post("/api/execute", json={"sol": 0.01})
    ok = (r_ok.status_code == 200 and r_ok.json().get("ok") is True and "execution" in r_ok.json())
    write_report("execute_ok", {
        "status": "PASS" if ok else "FAIL",
        "endpoint": "/api/execute",
        "expected": "{ ok: true, execution: '<text>' }",
        "actual": r_ok.json()
    })
    assert ok

    with TempRename(exe_file):
        r_err = client.post("/api/execute", json={"sol": 0.01})
        ok_err = (r_err.status_code == 200 and r_err.json().get("ok") is False and "error" in r_err.json())
        write_report("execute_error", {
            "status": "PASS" if ok_err else "FAIL",
            "endpoint": "/api/execute",
            "expected": "{ ok: false, error: '<msg>' } when file missing",
            "actual": r_err.json(),
            "note": "execution.txt temporarily renamed to simulate error"
        })
        assert ok_err