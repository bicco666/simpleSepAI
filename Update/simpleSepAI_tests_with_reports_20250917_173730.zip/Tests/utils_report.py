from pathlib import Path
from datetime import datetime
import json

def project_root_from_tests() -> Path:
    return Path(__file__).resolve().parents[1]

def write_report(name: str, summary: dict) -> Path:
    root = project_root_from_tests()
    report_dir = root / "Report"
    report_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    summary = {**summary, "timestamp": ts}
    lines = []
    lines.append(f"Test: {name}")
    lines.append(f"Status: {summary.get('status','UNKNOWN')}")
    if 'endpoint' in summary: lines.append(f"Endpoint: {summary['endpoint']}")
    if 'expected' in summary: lines.append(f"Expected: {summary['expected']}")
    if 'actual' in summary: lines.append(f"Actual: {summary['actual']}")
    if 'note' in summary: lines.append(f"Note: {summary['note']}")
    lines.append("")
    lines.append("JSON:")
    lines.append(json.dumps(summary, ensure_ascii=False, indent=2))
    content = "\n".join(lines) + "\n"
    path = report_dir / f"{name.replace(' ','_')}.txt"
    path.write_text(content, encoding="utf-8")
    return path